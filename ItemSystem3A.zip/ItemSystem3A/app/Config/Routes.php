<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/welcome', 'Home::index');
$routes->get('/register', 'RegistrationController::index');
$routes->post('/register', 'RegistrationController::create');